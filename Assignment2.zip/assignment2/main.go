package main

import (
	"assignment2/question1"
	"assignment2/question2"
	"assignment2/question3"
)

func main(){
	question1.Main1()
	question2.RunQ2()
	question3.MainQ3()
}

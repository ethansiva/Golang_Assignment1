package question1

import "fmt"

var WhatIsThe int = AnswerToLife()

func AnswerToLife() int{
	return 42
}


func Main1(){
	func () {
		WhatIsThe = 0
	}()

	if WhatIsThe == 0{
		fmt.Println("It's all a lie")
	}
}
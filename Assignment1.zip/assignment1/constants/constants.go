package constants

const Number1 int = 6
const Number2 int = 5

const Phrase string = "Hello World" 